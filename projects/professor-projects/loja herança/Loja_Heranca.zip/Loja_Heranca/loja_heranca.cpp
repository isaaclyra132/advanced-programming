#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cmath>
#include <limits>
#include "loja_heranca.h"

using namespace std;

void Produto::digitar()
{
  // Leh o nomr do produto
  do
  {
    cout << "Nome: ";
    getline(cin,nome);
  } while (nome=="");
  // Leh o preco do produto
  double Pr;
  do
  {
    cout << "Preco (##.##): ";
    cin >> Pr;
  } while (Pr <= 0.0);
  cin.ignore();
  preco = (unsigned)round(100.0*Pr);
}

bool Produto::ler(istream &I)
{
  // Limpa o conteudo anterior
  nome = "";
  preco = 0;

  // Formato da linha no arquivo-> "STRING_AUTOR";$FLOAT_PRECO
  // Ignora ateh aspa inicial
  I.ignore(numeric_limits<streamsize>::max(),'"');
  // Leh ateh a aspa final do nome do produto
  getline(I,nome,'"');
  // Ignora o ";" e o "$"
  I.ignore(numeric_limits<streamsize>::max(),'$');
  // Leh o preco como numero real
  double Pr;
  I >> Pr;
  // Converte o preco para centavos (inteiro)
  preco = (unsigned)round(100.0*Pr);
  // Testa a leitura
  if (nome=="" || preco==0)
  {
    nome = "";
    preco = 0;
    return false;
  }
  return true;
}

void Produto::salvar(ostream &O) const
{
  // Formato da linha-> "STRING_NOME";$FLOAT_PRECO;
  O << '"' << nome << '"' << ";$" << fixed << setprecision(2) << double(preco)/100.0;
}

void Livro::digitar()
{
  Produto::digitar();
  do
  {
    cout << "Autor: ";
    getline(cin,autor);
  } while (autor=="");
}

bool Livro::ler(istream &I)
{
  // Formato da linha no arquivo->  L: <Conteudo do Produto>;"STRING_AUTOR"

  // Leh o caractere inicial
  char opcao;
  I >> opcao;
  if (opcao!='L')
  {
    *this = Livro();
    return false;
  }
  // Ignora o ":" apos a letra inicial
  I.ignore(numeric_limits<streamsize>::max(),':');
  // Comeca da aspa da string do nome do Produto
  if (!Produto::ler(I))
  {
    *this = Livro();
    return false;
  }
  // Ignora o ";" e a aspa inicial do nome do autor
  I.ignore(numeric_limits<streamsize>::max(),'"');
  // Leh o nome do autor
  getline(I,autor,'"');
  // Ignora o "\n" no fim da linha
  I.ignore();
  if (autor == "")
  {
    *this = Livro();
    return false;
  }
  return true;
}

void Livro::salvar(ostream &O) const
{
  // Formato da linha-> L: <Conteudo do Produto>;"STRING_AUTOR"
  O << "L: ";
  Produto::salvar(O);
  O << ';' << '"' << autor << '"';
}

void CD::digitar()
{
  Produto::digitar();
  do
  {
    cout << "Numero de faixas: ";
    cin >> nfaixas;
  } while (nfaixas == 0);
  cin.ignore();
}

bool CD::ler(istream &I)
{
  // Formato da linha no arquivo->  C: <Conteudo do Produto>;UNSIGNED_NFAIXAS

  // Leh o caractere inicial
  char opcao;
  I >> opcao;
  if (opcao!='C')
  {
    *this = CD();
    return false;
  }
  // Ignora o ":" apos a letra inicial
  I.ignore(numeric_limits<streamsize>::max(),':');
  // Comeca da aspa da string do nome do Produto
  if (!Produto::ler(I))
  {
    *this = CD();
    return false;
  }
  // Ignora o ";"
  I.ignore(numeric_limits<streamsize>::max(),';');
  // Leh o numero de faixa
  I >> nfaixas;
  // Ignora o "\n" no fim da linha
  I.ignore();
  if (nfaixas == 0)
  {
    *this = CD();
    return false;
  }
  return true;
}

void CD::salvar(ostream &O) const
{
  // Formato da linha-> C: <Conteudo do Produto>;UNSIGNED_NFAIXAS
  O << "C: ";
  Produto::salvar(O);
  O << ';' << nfaixas;
}

void DVD::digitar()
{
  Produto::digitar();
  do
  {
    cout << "Duracao: ";
    cin >> duracao;
  } while (duracao == 0);
  cin.ignore();
}

bool DVD::ler(istream &I)
{
  // Formato da linha no arquivo-> D: <Conteudo do Produto>;UNSIGNED_DURACAO

  // Leh o caractere inicial
  char opcao;
  I >> opcao;
  if (opcao!='D')
  {
    *this = DVD();
    return false;
  }
  // Ignora o ":" apos a letra inicial
  I.ignore(numeric_limits<streamsize>::max(),':');
  // Comeca da aspa da string do nome do Produto
  if (!Produto::ler(I))
  {
    *this = DVD();
    return false;
  }
  // Ignora o ";"
  I.ignore(numeric_limits<streamsize>::max(),';');
  // Leh a duracao
  I >> duracao;
  // Ignora o "\n" no fim da linha
  I.ignore();
  if (duracao == 0)
  {
    *this = DVD();
    return false;
  }
  return true;
}

void DVD::salvar(ostream &O) const
{
  // Formato da linha-> D: <Conteudo do Produto>;UNSIGNED_DURACAO
  O << "D: ";
  Produto::salvar(O);
  O << ';' << duracao;
}

void ListaLivro::copiar(const ListaLivro &X)
{
  N = X.N;
  x = new Livro[N];
  for (unsigned i=0; i<N; i++) x[i] = X.x[i];
}

void ListaLivro::limpar()
{
  if (x!=NULL) delete[] x;
  x = NULL;
  N = 0;
}

void ListaLivro::incluir(const Livro &L)
{
  Livro *novoX = new Livro[N+1];
  for (unsigned i=0; i<N; i++) novoX[i] = x[i];
  novoX[N] = L;  // Acrescenta o novo Livro no fim do vetor
  N++;
  if (x!=NULL) delete[] x;
  x = novoX;
}

bool ListaLivro::excluir(unsigned id)
{
  if (N==0 || id>=N) return false;
  N--;
  Livro *novoX = (N>0 ? new Livro[N] : NULL);
  if (N>0) for (unsigned i=0; i<N; i++) novoX[i] = (i<id ? x[i] : x[i+1]);
  if (x!=NULL) delete[] x;
  x = novoX;
  return true;
}

void ListaLivro::imprimir() const
{
  cout << ">> LIVROS:" << endl;
  for (unsigned i=0; i<N; i++) cout << i << ") " << x[i] << endl;
}

bool ListaLivro::ler(istream &I)
{
  string pS;
  unsigned NN;
  Livro L;

  I >> pS >> NN;
  I.ignore();
  if (pS!="LISTALIVRO" || NN==0)
  {
    return false;
  }
  limpar();
  for (unsigned i=0; i<NN; i++)
  {
    if (!L.ler(I))
    {
      limpar();
      return false;
    }
    incluir(L);
  }
  return true;
}

void ListaLivro::salvar(ostream &O) const
{
  O << "LISTALIVRO " << N << endl;
  for (unsigned i=0; i<N; i++) O << x[i] << endl;
}

void ListaCD::copiar(const ListaCD &X)
{
  N = X.N;
  x = new CD[N];
  for (unsigned i=0; i<N; i++) x[i] = X.x[i];
}

void ListaCD::limpar()
{
  if (x!=NULL) delete[] x;
  x = NULL;
  N = 0;
}

void ListaCD::incluir(const CD &L)
{
  CD *novoX = new CD[N+1];
  for (unsigned i=0; i<N; i++) novoX[i] = x[i];
  novoX[N] = L;  // Acrescenta o novo CD no fim do vetor
  N++;
  if (x!=NULL) delete[] x;
  x = novoX;
}

bool ListaCD::excluir(unsigned id)
{
  if (N==0 || id>=N) return false;
  N--;
  CD *novoX = (N>0 ? new CD[N] : NULL);
  if (N>0) for (unsigned i=0; i<N; i++) novoX[i] = (i<id ? x[i] : x[i+1]);
  if (x!=NULL) delete[] x;
  x = novoX;
  return true;
}

void ListaCD::imprimir() const
{
  cout << ">> CDS:" << endl;
  for (unsigned i=0; i<N; i++) cout << i << ") " << x[i] << endl;
}

bool ListaCD::ler(istream &I)
{
  string pS;
  unsigned NN;
  CD C;

  I >> pS >> NN;
  I.ignore();
  if (pS!="LISTACD" || NN==0)
  {
    return false;
  }
  limpar();
  for (unsigned i=0; i<NN; i++)
  {
    if (!C.ler(I))
    {
      limpar();
      return false;
    }
    incluir(C);
  }
  return true;
}

void ListaCD::salvar(ostream &O) const
{
  O << "LISTACD " << N << endl;
  for (unsigned i=0; i<N; i++) O << x[i] << endl;
}

void ListaDVD::copiar(const ListaDVD &X)
{
  N = X.N;
  x = new DVD[N];
  for (unsigned i=0; i<N; i++) x[i] = X.x[i];
}

void ListaDVD::limpar()
{
  if (x!=NULL) delete[] x;
  x = NULL;  // Nao eh necessario
  N = 0;   // Nao eh necessario
}

void ListaDVD::incluir(const DVD &L)
{
  DVD *novoX = new DVD[N+1];
  for (unsigned i=0; i<N; i++) novoX[i] = x[i];
  novoX[N] = L;  // Acrescenta o novo DVD no fim do vetor
  N++;
  if (x!=NULL) delete[] x;
  x = novoX;
}

bool ListaDVD::excluir(unsigned id)
{
  if (N==0 || id>=N) return false;
  N--;
  DVD *novoX = (N>0 ? new DVD[N] : NULL);
  if (N>0) for (unsigned i=0; i<N; i++) novoX[i] = (i<id ? x[i] : x[i+1]);
  if (x!=NULL) delete[] x;
  x = novoX;
  return true;
}

void ListaDVD::imprimir() const
{
  cout << ">> DVDS:" << endl;
  for (unsigned i=0; i<N; i++) cout << i << ") " << x[i] << endl;
}

bool ListaDVD::ler(istream &I)
{
  string pS;
  unsigned NN;
  DVD D;

  I >> pS >> NN;
  I.ignore();
  if (pS!="LISTADVD" || NN==0)
  {
    return false;
  }
  limpar();
  for (unsigned i=0; i<NN; i++)
  {
    if (!D.ler(I))
    {
      limpar();
      return false;
    }
    incluir(D);
  }
  return true;
}

void ListaDVD::salvar(ostream &O) const
{
  O << "LISTADVD " << N << endl;
  for (unsigned i=0; i<N; i++) O << x[i] << endl;
}

void Loja::imprimir() const
{
  LL.imprimir();
  LC.imprimir();
  LD.imprimir();
}

bool Loja::ler(const string& arq)
{
  ifstream myfile(arq.c_str());
  if (!myfile.is_open()) return false;

  bool status=LL.ler(myfile);
  if (status) status=LC.ler(myfile);
  if (status) status=LD.ler(myfile);
  if (!status )
  {
    *this = Loja();
  }
  myfile.close();
  return status;
}

bool Loja::salvar(const string& arq) const
{
  ofstream myfile(arq.c_str());
  if (!myfile.is_open()) return false;

  LL.salvar(myfile);
  LC.salvar(myfile);
  LD.salvar(myfile);

  myfile.close();
  return true;
}
