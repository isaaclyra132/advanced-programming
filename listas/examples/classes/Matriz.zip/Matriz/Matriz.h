#ifndef _MATRIZ_H_
#define _MATRIZ_H_

#include <iostream>

using namespace std;

class Matriz
{
private:
  /// As dimensoes da matriz (sempre >= 0)
  unsigned NL, NC;
  /// O ponteiro para o array de ponteiros para elementos
  double **x;

  /// Esse eh um metodo privado da classe
  /// Aloca (reserva) memoria para uma matriz numL x numC elementos
  /// Deve ser usado no construtor por copia e em construtores especificos
  /// Quando for usado em uma matriz que nao seja recem-criada, ou seja,
  /// quando for usado fora de um construtor, deve ser sempre precedido de
  /// uma chamada ao metodo "clean"
  void create(unsigned numL, unsigned numC);

  /// Esse eh um metodo privado da classe
  /// Chama o metodo create e depois copia todos os elementos da matriz original
  /// Deve ser usado no construtor por copia e no operador de atribuicao
  /// Quando for usado em uma matriz que nao seja recem-criada, ou seja,
  /// quando for usado fora de um construtor, deve ser sempre precedido de
  /// uma chamada ao metodo "clean"
  void copy(const Matriz &N);

public:
  /// Construtor default (obrigatorio jah que a classe envolve alocacao de memoria)
  /// Como sua implementacao eh trivial, foi definido como inline
  inline Matriz(): NL(0), NC(0), x(NULL) {}  // Default
  /// Construtor por copia (obrigatorio jah que a classe envolve alocacao de memoria)
  /// Como sua implementacao eh trivial, foi definido como inline
  inline Matriz(const Matriz &N) {copy(N);}  // Copia
  /// Um construtor especifico,
  /// no qual os parametros de entrada indicam a dimensao da matriz
  inline Matriz(unsigned numL, unsigned numC) {create(numL, numC);}  // Espec�fico

  /// Essa eh um metodo publico da classe que libera a memoria
  /// Deve ser usado no construtor por copia e no operador de atribuicao
  void clean();
  /// Destrutor (obrigatorio jah que a classe envolve alocacao de memoria)
  /// Como sua implementacao eh trivial, foi definido como inline
  inline ~Matriz() {clean();}

  /// Operador de atribuicao (obrigatorio jah que a classe envolve alocacao de memoria)
  void operator=(const Matriz &N);

  /// Metodos de consulta que retornam as dimensoes da matriz
  /// Como sua implementacao eh trivial, foram definidos como inline
  inline unsigned getNumL(void) const {return NL;}
  inline unsigned getNumC(void) const {return NC;}

  /// Metodo de consulta que retorna o valor de um elemento da matriz
  /// Este metodo eh chamado no lado direito de uma operacao
  /// Por exemplo, y = x.at(2,3) ou cout << x.at(2,3)
  /// Nao foi sobrecarregado o operador[] que eh normalmente utilizado
  /// para indices porque ele soh permite um unico parametro
  double at(unsigned i, unsigned j) const;

  /// Metodo de fixacao de valor que retorna uma referencia para um elemento da matriz
  /// Este metodo eh chamado no lado esquerdo de uma operacao
  /// Por exemplo, x.set(2,3) = 7.0 ou cin >> x.set(2,3)
  /// Nao foi sobrecarregado o operador[] que eh normalmente utilizado
  /// para indices porque ele soh permite um unico parametro
  double& set(unsigned i, unsigned j);

  /// As funcoes que implementam os operadores de entrada e saida de dados
  /// Como nao sao metodos da classe (sao funcoes) mas precisam acessar dados privados
  /// da classe, sao declaradas como friend
  friend ostream &operator<<(ostream &X, const Matriz &N);
  friend istream &operator>>(istream &X, Matriz &N);


  /// Operadores algebricos
  Matriz operator+(const Matriz &N) const;
  inline const Matriz &operator+() const {return *this;}
  Matriz operator-(const Matriz &N) const;
  Matriz operator-() const;
  Matriz operator*(const Matriz &N) const;

  /// Operacoes matriciais
  Matriz operator!(void) const;  // Transposta
  double determinante(void) const;
  Matriz operator~(void) const;  // Inversa
  inline Matriz operator/(const Matriz &N) const {return operator*(~N);}
};

/// Declaracao de algumas operacoes matriciais que jah foram declaradas como
/// metodos utilizando uma notacao alternativa, como funcoes
/// Por exemplo, se A eh uma matriz, pode-se usar:
/// A.determinante(); ou
/// determinante(A);
/// AS funcoes simplesmente chamam o metodo correspondente
/// Notar que as funcoes nao precisam ser declaradas friend pq nao usam membros privados
inline Matriz transposta(const Matriz &N) {return !N;}
inline double determinante(const Matriz &N) {return N.determinante();}
inline Matriz inversa(const Matriz &N) {return ~N;}

#endif // _MATRIZ_H_
