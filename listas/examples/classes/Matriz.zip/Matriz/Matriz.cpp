#include "Matriz.h"

/// Esse eh um metodo privado da classe
/// Aloca (reserva) memoria para uma matriz numL x numC elementos
/// Deve ser usado no construtor por copia e em construtores especificos
/// Quando for usado em uma matriz que nao seja recem-criada, ou seja,
/// quando for usado fora de um construtor, deve ser sempre precedido de
/// uma chamada ao metodo "clean"
void Matriz::create(unsigned numL, unsigned numC)
{
  // Essa funcao soh deve ser chamada sozinha se vc tiver certeza que o objeto estah vazio
  // Por exemplo, em um construtor.
  // Caso nao tenha certeza, deve ser chamada primeiro a funcao clean
  if (numL==0 || numC==0)
  {
    NL = NC = 0;
    x = NULL;
    return;
  }
  NL = numL;
  NC = numC;

  // Aloca o vetor de linhas
  x = new double*[NL];

  // Aloca as linhas
  //
  // Versao 1: aloca um vetor para cada linha da matriz
  /*
  for (unsigned i=0; i<NL; i++) x[i] = new double[NC];
  */
  //
  // Versao 2: aloca uma area para todas as linhas de uma soh vez
  x[0] = new double[NL*NC];
  for (unsigned i=1; i<NL; i++) x[i] = x[i-1] + NC;
}

/// Esse eh um metodo privado da classe
/// Chama o metodo create e depois copia todos os elementos da matriz original
/// Deve ser usado no construtor por copia e no operador de atribuicao
/// Quando for usado em uma matriz que nao seja recem-criada, ou seja,
/// quando for usado fora de um construtor, deve ser sempre precedido de
/// uma chamada ao metodo "clean"
void Matriz::copy(const Matriz &N)
{
  // Essa funcao soh deve ser chamada sozinha se vc tiver certeza que o objeto estah vazio
  // Por exemplo, em um construtor.
  // Caso nao tenha certeza, deve ser chamada primeiro a funcao clean
  create(N.NL, N.NC);
  for (unsigned i=0; i<NL; i++)
  {
    for (unsigned j=0; j<NC; j++) x[i][j] = N.x[i][j];
  }
}

/// Essa eh um metodo publico da classe que libera a memoria
/// Deve ser usado no construtor por copia e no operador de atribuicao
void Matriz::clean()
{
  if (x!=NULL)
  {
    // Libera as linhas
    //
    // Versao 1: aloca um vetor para cada linha da matriz
    /*
    for (unsigned i=0; i<NL; i++) if (x[i]!=NULL) delete[] x[i];
    */
    //
    // Versao 2: aloca uma area para todas as linhas de uma soh vez
    if (x[0]!=NULL) delete[] x[0];

    // Libera o vetor de linhas
    delete[] x;
  }
  NL = NC = 0;
  x = NULL;
}

/// Operador de atribuicao (obrigatorio jah que a classe envolve alocacao de memoria)
void Matriz::operator=(const Matriz &N)
{
  // Inicialmente, testa se nah estah fazendo A=A
  // Soh faz alguma coisa se nao for isso
  if (this!=&N)
  {
    // Se as duas matrizes tem a mesma dimensao, basta copy os valores
    // Nao precisa desalocar e alocar novamente a matriz sendo atribuida
    if (NL==N.NL && NC==N.NC)
    {
      for (unsigned i=0; i<NL; i++)
      {
        for (unsigned j=0; j<NC; j++) x[i][j] = N.x[i][j];
      }
    }
    else
    {
      // As dimensoes sao diferentes
      // Libera a area antiga e aloca nova area, criando uma copia
      clean();
      copy(N);
    }
  }
}

/// Metodo de consulta que retorna o valor de um elemento da matriz
/// Este metodo eh chamado no lado direito de uma operacao
/// Por exemplo, y = x.at(2,3) ou cout << x.at(2,3)
/// Nao foi sobrecarregado o operador[] que eh normalmente utilizado
/// para indices porque ele soh permite um unico parametro
double Matriz::at(unsigned i, unsigned j) const
{
  if (i>=NL || j>=NC)
  {
    cerr << "Indices incompativeis\n";
    return 0.0;
  }
  return x[i][j];
}

/// Metodo de fixacao de valor que retorna uma referencia para um elemento da matriz
/// Este metodo eh chamado no lado esquerdo de uma operacao
/// Por exemplo, x.set(2,3) = 7.0 ou cin >> x.set(2,3)
/// Nao foi sobrecarregado o operador[] que eh normalmente utilizado
/// para indices porque ele soh permite um unico parametro
double& Matriz::set(unsigned i, unsigned j)
{
  static double erro(0.0);
  if (i>=NL || j>=NC)
  {
    cerr << "Indices incompativeis\n";
    return erro;
  }
  return x[i][j];
}

/// A funcao friend que implementa o operador de saida de dados
ostream &operator<<(ostream &X, const Matriz &N)
{
  if (N.NL==0 || N.NC==0)
  {
    // Nao hah nada a imprimir
    return X;
  }
  for (unsigned i=0; i<N.NL; i++)
  {
    for (unsigned j=0; j<N.NC; j++)
    {
      X << N.x[i][j] << ' ';
    }
    X << endl;
  }
  return X;
}

/// A funcao friend que implementa o operador de entrada de dados
istream &operator>>(istream &X, Matriz &N)
{
  if (N.NL==0 || N.NC==0)
  {
    cerr << "Matriz de dimensao nula\n";
    return X;
  }
  for (unsigned i=0; i<N.NL; i++)
  {
    for (unsigned j=0; j<N.NC; j++)
    {
      X >> N.x[i][j];
    }
  }
  return X;
}

/// Soma de maatrizes
Matriz Matriz::operator+(const Matriz &N) const
{
  if (NL != N.NL || NC != N.NC || NL==0 || NC==0)
  {
    cerr << "Matrizes de dimensao incompativeis ou nulas\n";
    return Matriz();
  }
  Matriz prov(NL,NC);
  for (unsigned i=0; i<NL; i++) for (unsigned j=0; j<NC; j++)
  {
    prov.x[i][j] = this->x[i][j] + N.x[i][j];
  }
  return prov;
}

/// Subtracao de matrizes
Matriz Matriz::operator-(const Matriz &N) const
{
  if (NL != N.NL || NC != N.NC || NL==0 || NC==0)
  {
    cerr << "Matrizes de dimensao incompativeis ou nulas\n";
    return Matriz();
  }
  Matriz prov(NL,NC);
  for (unsigned i=0; i<NL; i++) for (unsigned j=0; j<NC; j++)
    prov.x[i][j] = this->x[i][j] - N.x[i][j];
  return prov;
}

/// Negativa de uma matriz
Matriz Matriz::operator-() const
{
  if (NL==0 || NC==0)
  {
    cerr << "Matriz de dimensao nula\n";
    return Matriz();
  }
  Matriz prov(NL,NC);
  for (unsigned i=0; i<NL; i++) for (unsigned j=0; j<NC; j++)
    prov.x[i][j] = - x[i][j];
  return prov;
}

/// Produto de matrizes
Matriz Matriz::operator*(const Matriz &N) const
{
  if (NC != N.NL || NL==0 || NC==0 || N.NC==0)
  {
    cerr << "Matrizes de dimensao incompativeis ou nulas\n";
    return Matriz();
  }
  Matriz prov(NL,N.NC);
  for (unsigned i=0; i<prov.NL; i++) for (unsigned j=0; j<prov.NC; j++)
  {
    prov.x[i][j] = 0.0;
    for (unsigned k=0; k<NC; k++) prov.x[i][j] += x[i][k]*N.x[k][j];
  }
  return prov;
}

/// Transposta de uma matriz
Matriz Matriz::operator!(void) const
{
  if (NL==0 || NC==0)
  {
    cerr << "Matriz de dimensao nula\n";
    return Matriz();
  }
  Matriz prov(NC,NL);
  for (unsigned i=0; i<NL; i++) for (unsigned j=0; j<NC; j++)
    prov.x[j][i] = x[i][j];
  return prov;

}
