#ifndef _VETOR_H_
#define _VETOR_H_

#include <iostream>

using namespace std;

class Vetor
{
private:
  /// A dimensao do vetor (sempre >= 0)
  unsigned N;
  /// O ponteiro que aponta para os elementos do vetor
  double *x;

  /// Esse eh um metodo privado da classe Vetor
  /// Aloca (reserva) memoria para um vetor de Num elementos
  /// Deve ser usado no construtor por copia e em construtores especificos
  /// Quando for usado em um vetor que nao seja recem-criado, ou seja,
  /// quando for usado fora de um construtor, deve ser sempre precedido de
  /// uma chamada ao metodo "clean"
  void create(unsigned Num);

  /// Esse eh um metodo privado da classe Vetor
  /// Chama o metodo create e depois copia todos os elementos do vetor original
  /// Deve ser usado no construtor por copia e no operador de atribuicao
  /// Quando for usado em um vetor que nao seja recem-criado, ou seja,
  /// quando for usado fora de um construtor, deve ser sempre precedido de
  /// uma chamada ao metodo "clean"
  void copy(const Vetor &V);

public:
  /// Construtor default (obrigatorio jah que a classe envolve alocacao de memoria)
  /// Como sua implementacao eh trivial, foi definido como inline
  inline Vetor(): N(0), x(NULL) {}
  /// Construtor por copia (obrigatorio jah que a classe envolve alocacao de memoria)
  /// Como sua implementacao eh trivial, foi definido como inline
  inline Vetor(const Vetor &V) {copy(V);}
  /// Um construtor especifico, no qual o parametro de entrada indica a dimensao do vetor
  /// Esse construtor NAO deve ser usado como conversor de unsigned -> Vetor, pois seria incorreto
  /// Por isso, foi declarado como explicit
  explicit Vetor(unsigned Num);

  /// Essa eh um metodo publico da classe Vetor que libera a memoria
  /// Deve ser usado no construtor por copia e no operador de atribuicao
  void clean();
  /// Destrutor (obrigatorio jah que a classe envolve alocacao de memoria)
  /// Como sua implementacao eh trivial, foi definido como inline
  inline ~Vetor() {clean();}
  /// Operador de atribuicao (obrigatorio jah que a classe envolve alocacao de memoria)
  void operator=(const Vetor &V);

  /// Metodo de consulta que retorna a dimensao do vetor
  /// Como sua implementacao eh trivial, foi definido como inline
  inline unsigned size() const {return N;}
  /// Metodo de consulta que retorna o valor de um elemento do vetor
  /// Este metodo eh chamado quando o [] aparece no lado direito de uma operacao
  /// Por exemplo, y = x[2] ou cout << x[2]
  double operator[](unsigned i) const;
  /// Metodo de fixacao de valor que retorna uma referencia para um elemento do vetor
  /// Este metodo eh chamado quando o [] aparece no lado esquerdo de uma operacao
  /// Por exemplo, x[2] = 7.0 ou cin >> x[2]
  double &operator[](unsigned i);

  /// As funcoes que implementam os operadores de entrada e saida de dados
  /// Como nao sao metodos da classe (sao funcoes) mas precisam acessar dados privados
  /// da classe, sao declaradas como friend
  friend ostream &operator<<(ostream &X, const Vetor &V);
  friend istream &operator>>(istream &X, Vetor &V);

  /// Soma de vetores
  Vetor operator+(const Vetor &V) const;
  /// Subtracao de vetores (- binario)
  Vetor operator-(const Vetor &V) const;
  /// Negativo de um vetor (- unario)
  Vetor operator-() const;

  /// Norma euclidiana de um vetor
  double norma() const;
  /// Produto escalar
  double escalar(const Vetor &V) const;
  /// Produto vetorial (apenas para vetores de dimensao 3)
  Vetor vetorial(const Vetor &V) const;
};

#endif
