#include <iostream>
#include <cmath>  // sqrt

#include "vetor.h"

/// Essa eh um metodo publico da classe Vetor que libera a memoria
/// Deve ser usado no construtor por copia e no operador de atribuicao
void Vetor::clean()
{
  if (x!=NULL) delete[] x;
  x = NULL;
  N = 0;
}

/// Esse eh um metodo privado da classe Vetor
/// Aloca (reserva) memoria para um vetor de Num elementos
/// Deve ser usado nos construtores
/// Quando for usado em um vetor que nao seja recem-criado, ou seja,
/// quando for usado fora de um construtor, deve ser sempre precedido de
/// uma chamada ao metodo "clean"
void Vetor::create(unsigned Num)
{
  N = Num;
  x = ( N>0 ? new double[N] : NULL );
}

/// Esse eh um metodo privado da classe Vetor
/// Chama o metodo create e depois copia todos os elementos do vetor original
/// Deve ser usado no construtor por copia e no operador de atribuicao
/// Quando for usado em um vetor que nao seja recem-criado, ou seja,
/// quando for usado fora de um construtor, deve ser sempre precedido de
/// uma chamada ao metodo "clean"
void Vetor::copy(const Vetor &V)
{
  create(V.N);
  for (unsigned i=0; i<N; i++) x[i] = V.x[i];
}

/// Um construtor especifico, no qual o parametro de entrada indica a dimensao do vetor
/// Esse construtor NAO deve ser usado como conversor de unsigned -> Vetor, pois seria incorreto
/// Por isso, foi declarado como explicit
Vetor::Vetor(unsigned Num)
{
  create(Num);
  /// Inicializa todos os elementos com zero
  for (unsigned i=0; i<N; i++) x[i] = 0.0;
}

/// Operador de atribuicao (obrigatorio jah que a classe envolve alocacao de memoria)
void Vetor::operator=(const Vetor &V)
{
  /// Primeiro, testa se o usuario nao estah fazendo uma atribuicao redundante, tal como A=A
  /// Soh faz alguma coisa se nao for esse tipo de situacao absurda
  if (this != &V)
  {
    /// Em seguida, testa se a dimensao dos dois vetores eh a mesma
    /// Se for, nao precisa desalocar e alocar de novo com outro tamanho.
    /// Dah para aproveitar a mesma area, copiando soh os valores dos elementos
    /// Caso as dimensoes sejam diferentes, desaloca a area anterior, aloca uma nova area
    /// e copia os valores dos elementos, usando as funcoes privadas clean e copy.
    if (this->N == V.N)
    {
      for (unsigned i=0; i<N; i++) x[i] = V.x[i];
    }
    else
    {
      clean();
      copy(V);
    }
  }
}

/// Metodo de consulta que retorna o valor de um elemento do vetor
/// Este metodo eh chamado quando o [] aparece no lado direito de uma operacao
/// Por exemplo, y = x[2] ou cout << x[2]
double Vetor::operator[](unsigned i) const
{
  if (i>=N)
  {
    cerr << "Indice invalido\n";
    return 0.0;
  }
  return x[i];
}

/// Metodo de consulta que retorna uma referencia para um elemento do vetor
/// Este metodo eh chamado quando o [] aparece no lado esquerdo de uma operacao
/// Por exemplo, x[2] = 7.0 ou cin >> x[2]
double &Vetor::operator[](unsigned i)
{
  static double prov=0.0;
  if (i>=N)
  {
    cerr << "Indice invalido\n";
    return prov;
  }
  return x[i];
}

/// As funcoes que implementam os operadores de entrada e saida de dados
/// Como nao sao metodos da classe (sao funcoes) mas precisam acessar dados privados
/// da classe, sao declaradas como friend

ostream &operator<<(ostream &X, const Vetor &V)
{
  X << '[';
  for (unsigned i=0; i<V.N; i++) X << V.x[i] << (i+1==V.N ? ']' : ';');
  return X;
}

istream &operator>>(istream &X, Vetor &V)
{
  for (unsigned i=0; i<V.N; i++) X >> V.x[i];
  return X;
}

/// Soma de vetores
Vetor Vetor::operator+(const Vetor &V) const
{
  if (N!=V.N)
  {
    cerr << "Dimensoes incompativeis\n";
    return Vetor();
  }
  Vetor prov(N);
  for (unsigned i=0; i<N; i++) prov.x[i] = x[i] + V.x[i];
  return prov;
}

/// Subtracao de vetores (- binario)
Vetor Vetor::operator-(const Vetor &V) const
{
  if (N!=V.N)
  {
    cerr << "Dimensoes incompativeis\n";
    return Vetor();
  }
  Vetor prov(N);
  for (unsigned i=0; i<N; i++) prov.x[i] = x[i] - V.x[i];
  return prov;
}

/// Negativo de um vetor (- unario)
Vetor Vetor::operator-() const
{
  Vetor prov(N);
  for (unsigned i=0; i<N; i++) prov.x[i] = -x[i];
  return prov;
}

/// Norma euclidiana de um vetor
double Vetor::norma() const
{
  double soma(0.0);
  for (unsigned i=0; i<N; i++) soma += x[i]*x[i];
  return sqrt(soma);
}

/// Produto escalar
double Vetor::escalar(const Vetor &V) const
{
  if (N!=V.N)
  {
    cerr << "Dimensoes incompativeis\n";
    return 0.0;
  }
  double prov(0.0);
  for (unsigned i=0; i<N; i++) prov += x[i]*V.x[i];
  return prov;
}

/// Produto vetorial (apenas para vetores de dimensao 3)
Vetor Vetor::vetorial(const Vetor &V) const
{
  if (N!=3 || N!=V.N)
  {
    cerr << "Dimensoes incompativeis\n";
    return Vetor();
  }
  Vetor prov(3);
  prov.x[0] = x[1]*V.x[2] - x[2]*V.x[1];
  prov.x[1] = x[2]*V.x[0] - x[0]*V.x[2];
  prov.x[2] = x[0]*V.x[1] - x[1]*V.x[0];
  return prov;
}
