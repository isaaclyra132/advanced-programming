/********************************************************************************
** Form generated from reading UI file 'mainjogovelha.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINJOGOVELHA_H
#define UI_MAINJOGOVELHA_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainJogoVelha
{
public:
    QAction *actionReiniciar;
    QAction *actionSair;
    QAction *actionExibir_ajuda;
    QWidget *centralWidget;
    QTableWidget *jogoVelha;
    QLabel *jogadorVez;
    QLabel *imgVez;
    QLabel *jogadorVencedor;
    QLabel *imgVencedor;
    QMenuBar *menuBar;
    QMenu *menuReiniciar;
    QMenu *menuAjuda;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainJogoVelha)
    {
        if (MainJogoVelha->objectName().isEmpty())
            MainJogoVelha->setObjectName(QString::fromUtf8("MainJogoVelha"));
        MainJogoVelha->resize(280, 184);
        actionReiniciar = new QAction(MainJogoVelha);
        actionReiniciar->setObjectName(QString::fromUtf8("actionReiniciar"));
        actionSair = new QAction(MainJogoVelha);
        actionSair->setObjectName(QString::fromUtf8("actionSair"));
        actionExibir_ajuda = new QAction(MainJogoVelha);
        actionExibir_ajuda->setObjectName(QString::fromUtf8("actionExibir_ajuda"));
        centralWidget = new QWidget(MainJogoVelha);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        jogoVelha = new QTableWidget(centralWidget);
        if (jogoVelha->columnCount() < 3)
            jogoVelha->setColumnCount(3);
        if (jogoVelha->rowCount() < 3)
            jogoVelha->setRowCount(3);
        jogoVelha->setObjectName(QString::fromUtf8("jogoVelha"));
        jogoVelha->setGeometry(QRect(20, 10, 122, 122));
        jogoVelha->setCornerButtonEnabled(false);
        jogoVelha->setRowCount(3);
        jogoVelha->setColumnCount(3);
        jogoVelha->horizontalHeader()->setVisible(false);
        jogoVelha->horizontalHeader()->setMinimumSectionSize(40);
        jogoVelha->horizontalHeader()->setDefaultSectionSize(40);
        jogoVelha->horizontalHeader()->setHighlightSections(false);
        jogoVelha->verticalHeader()->setVisible(false);
        jogoVelha->verticalHeader()->setMinimumSectionSize(40);
        jogoVelha->verticalHeader()->setDefaultSectionSize(40);
        jogoVelha->verticalHeader()->setHighlightSections(false);
        jogadorVez = new QLabel(centralWidget);
        jogadorVez->setObjectName(QString::fromUtf8("jogadorVez"));
        jogadorVez->setGeometry(QRect(190, 5, 81, 16));
        imgVez = new QLabel(centralWidget);
        imgVez->setObjectName(QString::fromUtf8("imgVez"));
        imgVez->setGeometry(QRect(190, 23, 40, 40));
        imgVez->setFrameShape(QFrame::Box);
        jogadorVencedor = new QLabel(centralWidget);
        jogadorVencedor->setObjectName(QString::fromUtf8("jogadorVencedor"));
        jogadorVencedor->setGeometry(QRect(190, 76, 47, 13));
        imgVencedor = new QLabel(centralWidget);
        imgVencedor->setObjectName(QString::fromUtf8("imgVencedor"));
        imgVencedor->setGeometry(QRect(190, 92, 40, 40));
        imgVencedor->setFrameShape(QFrame::Box);
        MainJogoVelha->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainJogoVelha);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 280, 21));
        menuReiniciar = new QMenu(menuBar);
        menuReiniciar->setObjectName(QString::fromUtf8("menuReiniciar"));
        menuAjuda = new QMenu(menuBar);
        menuAjuda->setObjectName(QString::fromUtf8("menuAjuda"));
        MainJogoVelha->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainJogoVelha);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainJogoVelha->setStatusBar(statusBar);

        menuBar->addAction(menuReiniciar->menuAction());
        menuBar->addAction(menuAjuda->menuAction());
        menuReiniciar->addAction(actionReiniciar);
        menuReiniciar->addSeparator();
        menuReiniciar->addAction(actionSair);
        menuAjuda->addAction(actionExibir_ajuda);

        retranslateUi(MainJogoVelha);

        QMetaObject::connectSlotsByName(MainJogoVelha);
    } // setupUi

    void retranslateUi(QMainWindow *MainJogoVelha)
    {
        MainJogoVelha->setWindowTitle(QCoreApplication::translate("MainJogoVelha", "Jogo da Velha", nullptr));
        actionReiniciar->setText(QCoreApplication::translate("MainJogoVelha", "Reiniciar", nullptr));
        actionSair->setText(QCoreApplication::translate("MainJogoVelha", "Sair", nullptr));
        actionExibir_ajuda->setText(QCoreApplication::translate("MainJogoVelha", "Exibir ajuda...", nullptr));
        jogadorVez->setText(QCoreApplication::translate("MainJogoVelha", "Jogador da vez:", nullptr));
        imgVez->setText(QString());
        jogadorVencedor->setText(QCoreApplication::translate("MainJogoVelha", "Vencedor:", nullptr));
        imgVencedor->setText(QString());
        menuReiniciar->setTitle(QCoreApplication::translate("MainJogoVelha", "Jogo", nullptr));
        menuAjuda->setTitle(QCoreApplication::translate("MainJogoVelha", "Ajuda", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainJogoVelha: public Ui_MainJogoVelha {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINJOGOVELHA_H
