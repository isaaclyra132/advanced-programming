#include <iostream>
#include <thread>

#include "mysocket.h"

using namespace std;

#define PORTA_TESTE "23456"
#define TIMEOUT_TESTE 15

/// Socket global
tcp_mysocket s;

/// Funcao principal da thread de leitura do socket
void main_thread(void)
{
  MYSOCKET_STATUS iResult;
  bool fim = false;
  string msg;

  cout << "Thread iniciada!\n";
  while (!fim)
  {
    iResult = s.read_string(msg, TIMEOUT_TESTE*1000);
    if (iResult == MYSOCKET_OK)
    {
      cout << "Mensagem recebida do cliente: " << msg << endl;
      if (msg == "FIM")
      {
        cout << "Cliente encerrou\n";
        s.close();
        fim = true;
      }
    }
    else
    {
      if (iResult==MYSOCKET_ERROR)
      {
        cout << "Erro na recepcao de msg do cliente. Desconectando\n";
        s.close();
        fim = true;
      }
      if (iResult==MYSOCKET_DISCONNECTED)
      {
        cout << "Cliente desconectou\n";
        s.close();
        fim = true;
      }
      if (iResult==MYSOCKET_TIMEOUT)
      {
        cout << "Inatividade de " << TIMEOUT_TESTE << " segundos\n";
      }
    }
  }
  cout << "Thread encerrada!\n";
}

int main(void)
{
  /// Socket de conexoes
  tcp_mysocket_server c;
  /// Thread de leitura
  thread thr;

  MYSOCKET_STATUS iResult;
  bool fim = false;
  string msg;

  // Inicializa a biblioteca de sockets (exigida no Windows)
  iResult = mysocket::init();
  if (iResult != MYSOCKET_OK) {
    cerr << "Biblioteca mysocket nao pode ser inicializada\n";
    exit(1);
  }

  // Coloca o socket de controle em modo de espera
  if (c.listen(PORTA_TESTE,1) != MYSOCKET_OK) {
    cerr << "N�o foi poss�vel abrir o socket de controle\n";
    fim = true;
  }
  else
  {
    // Aguarda uma conexao
    cout << "Aguardando conexao do cliente...\n";
    if (c.accept(s) == MYSOCKET_OK)
    {
      cout << "Cliente conectado no socket " << s << endl;
    }
    else
    {
      cerr << "N�o foi poss�vel estabelecer uma conex�o\n";
      fim = true;
    }
  }

  // Cria a thread
  if (!fim)
  {
    thr = thread(main_thread);
    if (!thr.joinable())
    {
      cerr << "Problema ao criar thread\n";
      fim = true;
    }
  }

  while (!fim)
  {
    do
    {
      cout << "Mensagem para o cliente [max " << MYSOCKET_TAM_MAX_STRING << " caracteres, FIM para terminar]: ";
      cin >> ws;
      getline(cin, msg);
    } while (msg.size()==0 || msg.size()>MYSOCKET_TAM_MAX_STRING);
    if (!fim) fim = (msg=="FIM");

    iResult = s.write_string(msg);
    if ( iResult == MYSOCKET_ERROR )
    {
      cerr << "Problema ao enviar mensagem para o cliente\n";
      s.close();
      fim = true;
    }
  }

  /// Desliga os sockets
  cout << "Encerrando o socket de conexoes\n";
  c.close();
  cout << "Encerrando o socket de comunicacao\n";
  s.close();

  /// Espera encerramento da outra thread
  if (thr.joinable()) thr.join();

  /// Encerramento da biblioteca de sockets
  mysocket::end();
}
