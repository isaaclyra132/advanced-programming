#include <iostream>
#include <string.h>

#include "mysocket.h"

using namespace std;

#define PORTA_TESTE "23456"

int main(void)
{
  mysocket_status iResult;
  tcp_mysocket_server c;
  tcp_mysocket s;

  bool fim = false;
  string msg;

  // Inicializa a biblioteca de sockets (exigida no Windows)
  iResult = mysocket::init();
  if (iResult != mysocket_status::SOCK_OK) {
    cerr << "Biblioteca mysocket nao pode ser inicializada\n";
    exit(1);
  }

  /// Coloca o socket de controle em modo de espera
  if (c.listen(PORTA_TESTE,1) != mysocket_status::SOCK_OK) {
    cerr << "N�o foi poss�vel abrir o socket de controle\n";
    fim = true;
  }
  else
  {
    // Aguarda uma conexao
    cout << "Aguardando conexao do cliente...\n";
    if (c.accept(s) == mysocket_status::SOCK_OK)
    {
      cout << "Cliente conectado no socket " << s << endl;
    }
    else
    {
      cerr << "N�o foi poss�vel estabelecer uma conex�o\n";
      fim = true;
    }
  }

  while (!fim)
  {
    cout << "Aguardando msg do cliente...\n";
    iResult = s.read_string(msg);
    if (iResult != mysocket_status::SOCK_OK)
    {
      if (iResult==mysocket_status::SOCK_ERROR)
      {
        cout << "Erro na recepcao de msg do cliente. Desconectando\n";
        s.close();
        fim = true;
      }
      if (iResult==mysocket_status::SOCK_DISCONNECTED)
      {
        cout << "Cliente desconectou\n";
        s.close();
        fim = true;
      }
      if (iResult==mysocket_status::SOCK_TIMEOUT)
      {
        // Nunca deve acontecer, jah que a read_string nao tem timeout
      }
    }
    else
    {
      cout << "Mensagem recebida do cliente: " << msg << endl;
      if (msg == "FIM")
      {
        cout << "Cliente encerrou\n";
        s.close();
        fim = true;
      }
    }

    if (!fim) do
    {
      cout << "Mensagem para o cliente [max " << MYSOCKET_TAM_MAX_STRING << " caracteres, FIM para terminar]: ";
      cin >> ws;
      getline(cin,msg);
    } while (msg.size()==0 || msg.size()>MYSOCKET_TAM_MAX_STRING);
    if (!fim) fim = (msg=="FIM");

    iResult = s.write_string(msg);
    if ( iResult == mysocket_status::SOCK_ERROR )
    {
      cerr << "Problema ao enviar mensagem para o cliente\n";
      s.close();
      fim = true;
    }
  }

  // Desliga os sockets
  cout << "Encerrando o socket de conexoes\n";
  c.close();
  cout << "Encerrando o socket de comunicacao\n";
  s.close();

  /// Encerramento da biblioteca de sockets
  mysocket::end();
}
