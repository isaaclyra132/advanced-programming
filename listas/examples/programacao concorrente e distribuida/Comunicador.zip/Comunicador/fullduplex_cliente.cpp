#include <iostream>
#include <thread>

#include "mysocket.h"

using namespace std;

#define PORTA_TESTE "23456"
#define TIMEOUT_TESTE 15

// Socket global
tcp_mysocket s;

/// Funcao principal da thread de leitura do socket
void main_thread(void)
{
  MYSOCKET_STATUS iResult;
  bool fim = false;
  string msg;

  cout << "Thread iniciada!\n";
  while (!fim)
  {
    iResult = s.read_string(msg, TIMEOUT_TESTE*1000);
    if (iResult == MYSOCKET_OK)
    {
      cout << "Mensagem recebida do servidor: " << msg << endl;
      if (msg == "FIM")
      {
        cout << "Servidor encerrou\n";
        s.close();
        fim = true;
      }
    }
    else
    {
      if (iResult==MYSOCKET_ERROR)
      {
        cerr << "Erro na recepcao de msg do servidor. Desconectando\n";
        s.close();
        fim = true;
      }
      if (iResult==MYSOCKET_DISCONNECTED)
      {
        cout << "Servidor desconectou\n";
        s.close();
        fim = true;
      }
      if (iResult==MYSOCKET_TIMEOUT)
      {
        cout << "Inatividade de " << TIMEOUT_TESTE << " segundos\n";
      }
    }
  }
  cout << "Thread encerrada!\n";
}

int main(int argc, char **argv)
{
  /// Thread de leitura
  thread thr;

  MYSOCKET_STATUS iResult;
  bool fim = false;
  string msg;

  // Inicializa a biblioteca de sockets (exigida no Windows)
  iResult = mysocket::init();
  if (iResult != MYSOCKET_OK) {
    cerr << "Biblioteca mysocket nao pode ser inicializada\n";
    exit(1);
  }

  if( argc<2 ) {
    cout << "Maquina onde esta rodando o servidor (IP): ";
    cin >> ws;
    getline(cin, msg);
  }
  else {
    msg = argv[1];
  }

  if (s.connect(msg.c_str(), PORTA_TESTE) == MYSOCKET_OK)
  {
    cout << "Conectado ao servidor " << msg << " na porta " << PORTA_TESTE
         << " pelo socket " << s << endl;
  }
  else
  {
    cerr << "Problema na conexao ao servidor " << msg << " na porta " << PORTA_TESTE << endl;
    fim = true;
  }

  // Cria a thread
  if (!fim)
  {
    thr = thread(main_thread);
    if (!thr.joinable())
    {
      cerr << "Problema ao criar thread\n";
      fim = true;
    }
  }

  while (!fim)
  {
    do
    {
      cout << "Mensagem a enviar (max " << MYSOCKET_TAM_MAX_STRING << " caracteres, FIM para terminar): ";
      cin >> ws;
      getline(cin, msg);
    } while (msg.size()==0 || msg.size()>MYSOCKET_TAM_MAX_STRING);
    if (!fim) fim = (msg=="FIM");

    iResult = s.write_string(msg);
    if ( iResult != MYSOCKET_OK )
    {
      cerr << "Problema ao enviar mensagem para o servidor\n";
      s.close();
      fim = true;
    }
  }

  /// Desliga o socket
  cout << "Encerrando o socket de comunicacao\n";
  s.close();

  /// Espera encerramento da outra thread
  if (thr.joinable()) thr.join();

  /// Encerramento da biblioteca de sockets
  mysocket::end();
}
