#include "mythread.h"
#include "pong.h"

using namespace std;

MyThread::MyThread(QObject *parent) : QObject(parent)
{
  th_id = NULL;
}

/// Esta eh a funcao principal da thread
/// Ela recebe as informacoes do socket e armazena na variavel DC,
/// de onde elas serao exibidas pela interface visual atraves da emissao de sinais
int MyThread::main()
{
  // O status de retorno das funcoes do socket
  MYSOCKET_STATUS iResult;

  while (sock.connected())
  {
    int32_t cmd;
    iResult = sock.read_int(cmd,1000*TIMEOUT_WHATSPROG);
    if (iResult > 0)
    {
      IterConversa it;
      int32_t id;

      switch(cmd)
      {
      case CMD_NEW_USER:
      case CMD_LOGIN_USER:
      case CMD_LOGIN_OK:
      case CMD_LOGIN_INVALIDO:
      case CMD_MSG_LIDA1:
      case CMD_LOGOUT_USER:
      default:
        // Ignorar: erro do servidor
        break;
      case CMD_NOVA_MSG:
      {
        string remetente;
        string texto;

        // Receber a msg
        iResult = sock.read_int(id, TIMEOUT_WHATSPROG*1000);
        if (iResult > 0) iResult = sock.read_string(remetente, TIMEOUT_WHATSPROG*1000);
        if (iResult > 0) iResult = sock.read_string(texto, TIMEOUT_WHATSPROG*1000);
        if (iResult > 0)
        {
          it = DC.findConversa(remetente);
          if (it == DC.end())
          {
            if (DC.insertConversa(remetente))
            {
              // A conversa recem-inserida eh a ultima
              it = DC.last();
              // Aumentou o numero de conversas
              // Atualiza a janela de conversas
              emit signAtualizaConversas();
            }
          }
          if (it != DC.end())
          {
            // Conversa existe (jah existia ou acabou de ser criada)
            Mensagem M;
            // Testa se os parametros da msg estao corretos
            if (M.setId(id) && M.setRemetente(remetente) && M.setDestinatario(DC.getMeuUsuario()) &&
                M.setTexto(texto) && M.setStatus(MSG_ENTREGUE))
            {
              // Insere a mensagem na conversa
              DC.pushMessage(it,M);
              // Move a conversa com a nova msg para o inicio da lista (begin)
              DC.moveConversaToBegin(it);
              // Modificou o numero de mensagens da conversa
              // Moveu a conversa dentro da lista
              // Atualizar a janela de conversas
              emit signAtualizaConversas();
              // Se a conversa onde a nova msg foi inserida estiver sendo visualizada,
              // devem ser enviadas as confirmacoes de leitura
              // A funcao de confirmacao jah atualiza as janelas de conversa e mensagens
              if (it == DC.getConversaAtual())
              {
                emit signEnviaConfirmacoesLeitura();
              }
            }
          }
        }
        else
        {
          // Nao conseguiu ler a msg recebida
          sock.close();
        }
        break;
      } // fim do case CMD_NOVA_MSG
      case CMD_MSG_RECEBIDA:
      case CMD_MSG_ENTREGUE:
      case CMD_MSG_LIDA2:
      {
        int ind_msg;

        // Receber a id
        iResult = sock.read_int(id, TIMEOUT_WHATSPROG*1000);
        if (iResult > 0)
        {
          // Procura se existe uma mensagem com essa id;
          DC.findMensagem(id, it, ind_msg);
          if (it!=DC.end() && ind_msg>=0)
          {
            // Encontrou a msg com essa id
            // Testa o status atual
            bool status_ok(false);
            MsgStatus novoStatus(MSG_INVALIDA);
            if (cmd==CMD_MSG_RECEBIDA)
            {
              status_ok = (it->getMensagem(ind_msg).getStatus()==MSG_ENVIADA);
              novoStatus = MSG_RECEBIDA;
            }
            if (cmd==CMD_MSG_ENTREGUE)
            {
              status_ok = (it->getMensagem(ind_msg).getStatus()==MSG_ENVIADA ||
                           it->getMensagem(ind_msg).getStatus()==MSG_RECEBIDA);
              novoStatus = MSG_ENTREGUE;
            }
            if (cmd==CMD_MSG_LIDA2)
            {
              status_ok = (it->getMensagem(ind_msg).getStatus()==MSG_ENVIADA ||
                           it->getMensagem(ind_msg).getStatus()==MSG_RECEBIDA ||
                           it->getMensagem(ind_msg).getStatus()==MSG_ENTREGUE);
              novoStatus = MSG_LIDA;
            }
            // Testa o remetente e o status
            if (it->getMensagem(ind_msg).getRemetente()==DC.getMeuUsuario() && status_ok)
            {
              // A msg encontrada eh de minha autoria e estah com um dos status correto
              DC.setStatus(it,ind_msg,novoStatus);
              // Testa se a conversa da msg que foi atualizada estah sendo exibida
              if (it == DC.getConversaAtual())
              {
                // Exibe em tela o novo status da msg
                emit signAtualizaMensagens();
              }
            }
            else
            {
              // A msg com essa id nao estah na situacao esperada
              // Ignorar: erro do servidor ou do cliente
            }
          }
          else
          {
            // Nao existe msg com essa id
            // Ignorar: erro do servidor ou do cliente
          }
        }
        else
        {
          // Nao conseguiu ler a id
          sock.close();
        }
        break;
      } // fim do case CMD_MSG_<status>
      case CMD_ID_INVALIDA:
      case CMD_USER_INVALIDO:
      case CMD_MSG_INVALIDA:
      {
        int ind_msg;

        // Receber a id
        iResult = sock.read_int(id, TIMEOUT_WHATSPROG*1000);
        if (iResult > 0)
        {
          // Procura se existe uma mensagem com essa id;
          DC.findMensagem(id, it, ind_msg);
          if (it!=DC.end() && ind_msg>=0)
          {
            // Encontrou a msg com essa id
            // Testa o remetente e o status
            if (it->getMensagem(ind_msg).getRemetente()==DC.getMeuUsuario() &&
                it->getMensagem(ind_msg).getStatus()==MSG_ENVIADA)
            {
              // A msg encontrada eh de minha autoria e estah com um dos status apropriado
              // Remover msg
              DC.eraseMessage(it,ind_msg);
              // Modificou o numero de mensagens da conversa
              // Atualizar as janelas
              emit signAtualizaConversas();
              emit signAtualizaMensagens();
              // Informar erro nos parametros da msg
              emit signExibirErroMensagem(QString("Mensagem (id=%1) com erro (%2)")
                                          .arg(id).arg(nome_cmd((ComandoWhatsProg)cmd).c_str()).toStdString());
            }
            else
            {
              // A msg com essa id nao estah na situacao esperada
              // Ignorar: erro do servidor ou do cliente
            }
          }
          else
          {
            // Nao existe msg com essa id
            // Ignorar: erro do servidor ou do cliente
          }
        }
        else
        {
          // Nao conseguiu ler a id
          sock.close();
        }
        break;
      } // Fim do case CMD_<campo>_INVALIDA
      } // Fim do switch
    }
    else // else if (iResult > 0) -> erro na sock.read_int(cmd)
    {
      // A leitura do comando (int) retornou
      // SOCKET_ERROR, SOCKET_DISCONNECTED ou SOCKET_TIMEOUT
      // Se for SOCKET_TIMEOUT, aproveita para salvar o arquivo com os dados
      // Nos outros dois casos, a conexao encerrou, de forma correta ou com erro.
      if (iResult == SOCKET_TIMEOUT)
      {
        if (!DC.salvar())
        {
          emit signExibirErroMensagem("Erro no salvamento do arquivo "+DC.getNomeArq());
        }
      }
      else
      {
        sock.close();
      }
    }
  } // fim do while (sock.connected())

  // Envia o comando de logout
  if (sock.connected())
  {
    sock.write_int(CMD_LOGOUT_USER);
  }

  // Encerra o socket
  sock.close();

  // Coloca a interface em modo desconectado
  emit signDesconectarInterface();

  // Libera o handle da thread
  CloseHandle(th_id);
  th_id = NULL;

  return 0;
}

/// Funcao que executa o metodo main da classe MyThread
DWORD WINAPI main_thread(LPVOID lpParameter)
{
  MyThread *thread = (MyThread*)lpParameter;
  return thread->main();
}

/// Iniciar a thread
bool MyThread::executar()
{
  th_id = CreateThread(NULL, 0, main_thread, this , 0, NULL);
  return (th_id != NULL);
}

/// Terminar a thread
void MyThread::encerrar(void)
{
  if (th_id != NULL)
  {
    if (WaitForSingleObject(th_id, 1000*TIMEOUT_WHATSPROG) == WAIT_TIMEOUT)
    {
      // A funcao WaitForSingleObject saiu por timeout
      // Encerra na forca bruta a thread de recepcao, pois ela nao terminou sozinha
      TerminateThread(th_id,0);
    }
    // Encerra o handle da thread
    CloseHandle(th_id);
  }
  th_id = NULL;
}
