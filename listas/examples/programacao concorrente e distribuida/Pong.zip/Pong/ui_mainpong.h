/********************************************************************************
** Form generated from reading UI file 'mainpong.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINPONG_H
#define UI_MAINPONG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainPong
{
public:
    QAction *actionIniciar;
    QAction *actionEncerrar;
    QAction *actionSair;
    QWidget *centralWidget;
    QLabel *labelBola;
    QLabel *labelBarra;
    QSlider *sliderBarra;
    QMenuBar *menuBar;
    QMenu *menuPong;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainPong)
    {
        if (MainPong->objectName().isEmpty())
            MainPong->setObjectName(QStringLiteral("MainPong"));
        MainPong->resize(243, 241);
        actionIniciar = new QAction(MainPong);
        actionIniciar->setObjectName(QStringLiteral("actionIniciar"));
        actionEncerrar = new QAction(MainPong);
        actionEncerrar->setObjectName(QStringLiteral("actionEncerrar"));
        actionSair = new QAction(MainPong);
        actionSair->setObjectName(QStringLiteral("actionSair"));
        centralWidget = new QWidget(MainPong);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        labelBola = new QLabel(centralWidget);
        labelBola->setObjectName(QStringLiteral("labelBola"));
        labelBola->setGeometry(QRect(43, 0, 200, 200));
        labelBarra = new QLabel(centralWidget);
        labelBarra->setObjectName(QStringLiteral("labelBarra"));
        labelBarra->setGeometry(QRect(22, 0, 21, 200));
        sliderBarra = new QSlider(centralWidget);
        sliderBarra->setObjectName(QStringLiteral("sliderBarra"));
        sliderBarra->setGeometry(QRect(0, 0, 22, 200));
        sliderBarra->setMinimum(-100);
        sliderBarra->setMaximum(100);
        sliderBarra->setSingleStep(10);
        sliderBarra->setValue(0);
        sliderBarra->setOrientation(Qt::Vertical);
        MainPong->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainPong);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 243, 21));
        menuPong = new QMenu(menuBar);
        menuPong->setObjectName(QStringLiteral("menuPong"));
        MainPong->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainPong);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainPong->setStatusBar(statusBar);

        menuBar->addAction(menuPong->menuAction());
        menuPong->addAction(actionIniciar);
        menuPong->addAction(actionEncerrar);
        menuPong->addSeparator();
        menuPong->addAction(actionSair);

        retranslateUi(MainPong);

        QMetaObject::connectSlotsByName(MainPong);
    } // setupUi

    void retranslateUi(QMainWindow *MainPong)
    {
        MainPong->setWindowTitle(QApplication::translate("MainPong", "Pong - Exemplo de threads em Qt", Q_NULLPTR));
        actionIniciar->setText(QApplication::translate("MainPong", "Iniciar", Q_NULLPTR));
        actionEncerrar->setText(QApplication::translate("MainPong", "Encerrar", Q_NULLPTR));
        actionSair->setText(QApplication::translate("MainPong", "Sair", Q_NULLPTR));
        labelBola->setText(QString());
        labelBarra->setText(QString());
        menuPong->setTitle(QApplication::translate("MainPong", "Pong", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainPong: public Ui_MainPong {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINPONG_H
