#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QObject>
#include "dados_cliente.h"

class MyThread: public QObject
{
  Q_OBJECT

public:
  explicit MyThread(QObject *parent = nullptr);
  /// Iniciar a thread
  bool executar();
  /// Terminar a thread
  void encerrar();

signals:
  void signEnviaConfirmacoesLeitura();
  void signAtualizaConversas();
  void signAtualizaMensagens();
  void signDesconectarInterface();
  void signExibirErroMensagem(const string&);

public slots:

private:
  HANDLE th_id;
  /// Esta eh a funcao principal da thread
  /// Ela recebe as informacoes do socket e armazena na variavel DC,
  /// de onde elas serao exibidas pela interface visual atraves da emissao de sinais
  int main();

  /// A funcao main_thread() executa o metodo main()
  friend DWORD WINAPI main_thread(LPVOID lpParameter);
};

#endif // MYTHREAD_H
