#include <iostream>
#include <thread>
#include <chrono>

using namespace std;

/// Variavel global (visivel nas 2 threads)
int N(0);

/// A funcao principal da thread
void main_thread(void)
{
  do
  {
    cout << "N=" << N << endl;
    this_thread::sleep_for(chrono::seconds(2)); // Espera 2 segundos
  } while(N<=5);
}

int main(int argc, char **argv)
{
  /// Cria a thread
  thread thr(main_thread);

  /// Laco principal da main
  do
  {
    cout << "Novo valor de N (>5 encerra o programa): ";
    cin >> N;
  } while(N<=5);

  /// Espera pelo fim da thread
  cout << "Aguardando o encerramento da thread...\n";
  if (thr.joinable()) thr.join();
}
