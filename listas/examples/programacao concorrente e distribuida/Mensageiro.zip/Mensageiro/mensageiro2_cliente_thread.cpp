#include <QMessageBox>

#include "mysocket.h"
#include "mensageiro2_cliente_thread.h"

using namespace std;

/// O socket do cliente, a ser utilizado por todas as threads
extern tcp_mysocket sock;

Mensageiro2_Cliente_Thread::Mensageiro2_Cliente_Thread(QObject *parent) :
  QObject(parent), thr()
{
}

/// Este eh o metodo principal da thread
/// Ele recebe as informacoes do socket e exibe atraves da emissao de sinais
void Mensageiro2_Cliente_Thread::main_thread()
{
  // O status de retorno das funcoes do socket
  mysocket_status iResult;

  string remetente,msg;
  bool erro(false);

  while (sock.connected())
  {
    iResult = sock.read_string(remetente);
    if (iResult == mysocket_status::SOCK_OK)
    {
      iResult = sock.read_string(msg);
      if (iResult == mysocket_status::SOCK_OK)
      {
        emit signAdicionarMsgRecebida(QString(remetente.c_str()),
                                      QString(msg.c_str()));
      }
      else
      {
        // A leitura da string retornou
        // mysocket_status::SOCK_ERROR, mysocket_status::SOCK_DISCONNECTED ou mysocket_status::SOCK_TIMEOUT
        // Se for mysocket_status::SOCK_TIMEOUT, nao precisa fazer nada. Na realidade,
        // mysocket_status::SOCK_TIMEOUT nunca deve acontecer, pois nao foi definido um timeout.
        // Nos outros dois casos, a conexao encerrou, de forma correta ou com erro.
        if (iResult != mysocket_status::SOCK_TIMEOUT)
        {
          sock.close();
          if (iResult == mysocket_status::SOCK_ERROR) erro=true;
        }
      }
    }
    else
    {
      // A leitura da string retornou
      // mysocket_status::SOCK_ERROR, mysocket_status::SOCK_DISCONNECTED ou mysocket_status::SOCK_TIMEOUT
      // Se for mysocket_status::SOCK_TIMEOUT, nao precisa fazer nada. Na realidade,
      // mysocket_status::SOCK_TIMEOUT nunca deve acontecer, pois nao foi definido um timeout.
      // Nos outros dois casos, a conexao encerrou, de forma correta ou com erro.
      if (iResult != mysocket_status::SOCK_TIMEOUT)
      {
        sock.close();
        if (iResult == mysocket_status::SOCK_ERROR) erro=true;
      }
    }
  }

  if (erro)
  {
    // Emitir msg de erro: conexao interrompida abruptamente
    QMessageBox msgBox;
    msgBox.setWindowTitle("Erro na recepcao");
    msgBox.setText("Erro na leitura do servidor");
    msgBox.exec();
  }

  // Fecha o socket se jah nao estiver fechado
  sock.close();

  // Coloca a interface em modo desconectado
  emit signInterfaceDesconectada();
}

/// Funcao que executa o metodo main da classe Mensageiro2_Cliente_Thread
void main_thread(Mensageiro2_Cliente_Thread *mct)
{
  mct->main_thread();
}

/// Iniciar a thread
bool Mensageiro2_Cliente_Thread::executar()
{
  if (!sock.connected())
  {
    // Emitir msg de erro: socket nao conectado
    QMessageBox msgBox;
    msgBox.setWindowTitle("Erro na execucao");
    msgBox.setText("Socket nao conectado");
    msgBox.exec();
    return false;
  }
  if (running())
  {
    sock.close();

    // Emitir msg de erro: thread jah estah em execucao
    QMessageBox msgBox;
    msgBox.setWindowTitle("Erro na execucao");
    msgBox.setText("Thread de leitura jah estah em execucao");
    msgBox.exec();
    return false;
  }
  thr = std::thread(::main_thread, this);
  if (!running())
  {
    sock.close();

    // Emitir msg de erro: nao foi possivel criar thread
    QMessageBox msgBox;
    msgBox.setWindowTitle("Erro na conexao");
    msgBox.setText("Nao foi possivel criar thread de leitura");
    msgBox.exec();
    return false;
  }
  // Thread estah funcionando
  emit signInterfaceConectada();
  return true;
}

/// Terminar a thread
void Mensageiro2_Cliente_Thread::encerrar(void)
{
  sock.close();
  if (thr.joinable()) thr.join();
  thr = std::thread();
}
