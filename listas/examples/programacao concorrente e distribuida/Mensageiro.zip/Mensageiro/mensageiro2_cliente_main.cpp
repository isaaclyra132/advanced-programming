#include <QApplication>

#include "mysocket.h"
#include "mensageiro2_cliente.h"

using namespace std;

// Variaveis globais
tcp_mysocket sock;

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  Mensageiro2_Cliente w;

  // Inicializa a biblioteca de sockets (exigida no Windows)
  mysocket_status iResult = mysocket::init();
  if (iResult != mysocket_status::SOCK_OK) {
    cerr << "Biblioteca mysocket nao pode ser inicializada\n";
    exit(1);
  }

  w.show();

  int prov = a.exec();

  // Espera pelo fim da thread de recepcao
  w.desconectar();

  // Encerra a biblioteca de sockets
  mysocket::end();

  return prov;
}
