/********************************************************************************
** Form generated from reading UI file 'connectserver.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONNECTSERVER_H
#define UI_CONNECTSERVER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_ConnectServer
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *labelServidor;
    QLabel *labelLogin;
    QLineEdit *editServidor;
    QLineEdit *editLogin;

    void setupUi(QDialog *ConnectServer)
    {
        if (ConnectServer->objectName().isEmpty())
            ConnectServer->setObjectName(QStringLiteral("ConnectServer"));
        ConnectServer->resize(235, 125);
        buttonBox = new QDialogButtonBox(ConnectServer);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(20, 80, 200, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        buttonBox->setCenterButtons(false);
        labelServidor = new QLabel(ConnectServer);
        labelServidor->setObjectName(QStringLiteral("labelServidor"));
        labelServidor->setGeometry(QRect(10, 10, 60, 16));
        labelLogin = new QLabel(ConnectServer);
        labelLogin->setObjectName(QStringLiteral("labelLogin"));
        labelLogin->setGeometry(QRect(10, 40, 60, 16));
        editServidor = new QLineEdit(ConnectServer);
        editServidor->setObjectName(QStringLiteral("editServidor"));
        editServidor->setGeometry(QRect(80, 10, 140, 20));
        editLogin = new QLineEdit(ConnectServer);
        editLogin->setObjectName(QStringLiteral("editLogin"));
        editLogin->setGeometry(QRect(80, 40, 140, 20));

        retranslateUi(ConnectServer);
        QObject::connect(buttonBox, SIGNAL(accepted()), ConnectServer, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ConnectServer, SLOT(reject()));

        QMetaObject::connectSlotsByName(ConnectServer);
    } // setupUi

    void retranslateUi(QDialog *ConnectServer)
    {
        ConnectServer->setWindowTitle(QApplication::translate("ConnectServer", "Conex\303\243o ao servidor", Q_NULLPTR));
        labelServidor->setText(QApplication::translate("ConnectServer", "SERVIDOR:", Q_NULLPTR));
        labelLogin->setText(QApplication::translate("ConnectServer", "LOGIN:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ConnectServer: public Ui_ConnectServer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONNECTSERVER_H
