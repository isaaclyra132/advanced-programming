#ifndef Mensageiro2_Cliente_Thread_H
#define Mensageiro2_Cliente_Thread_H

#include <QObject>
#include <QString>
#include <thread>

class Mensageiro2_Cliente_Thread: public QObject
{
  Q_OBJECT

private:
  /// A thread de leitura do socket no cliente
  std::thread thr;

  /// Este eh o metodo principal da thread
  /// Ele recebe as informacoes do socket e exibe atraves da emissao de sinais
  void main_thread();

  /// A funcao main_thread() executa o metodo main_thread()
  friend void main_thread(Mensageiro2_Cliente_Thread *mct);

public:
  explicit Mensageiro2_Cliente_Thread(QObject *parent = nullptr);
  inline bool running() const {return thr.joinable();}

signals:
  void signInterfaceConectada();
  void signInterfaceDesconectada();
  void signAdicionarMsgRecebida(QString, QString);

private slots:
  /// Iniciar a thread
  bool executar();
  /// Terminar a thread
  void encerrar();
};

#endif // Mensageiro2_Cliente_Thread_H
